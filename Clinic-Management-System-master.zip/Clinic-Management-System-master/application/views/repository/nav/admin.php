  <!--<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
      <span class="glyphicon glyphicon-search"></span> Search <b class="caret"></b>
    </a>
    <ul class="dropdown-menu" style="min-width: 300px;">
      <li>
        <div class="row">
          <div class="col-md-12">
            <form class="navbar-form navbar-left" role="search">
              <div class="input-group">
                <input name="q" type="text" class="form-control" placeholder="Search" />
                <span class="input-group-btn">
                  <button class="btn btn-primary" type="button"> Go!</button>
                </span>
              </div>
            </form>
          </div>
        </div>
      </li>
    </ul>
  </li>-->
</ul>
<ul class="nav navbar-nav navbar-right">
  <!-- navbar right align items -->
